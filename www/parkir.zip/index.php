<html>
	<head>
		<title>GetParking Parkir</title>
		<style>
			table {
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid black;
}
button {
    width: 10%;
    background-color: #DF0101;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: #B40404;
}
		</style>
		<link rel="shortcut icon" href="images/parkir.png">
	</head>
	<body background="images/background.jpg" style="background-repeat: no-repeat; background-size: cover">
		<center><br><br>
		<table width=70% height=70%>
			<tr><td bgcolor=#8A0808><br><h1 align=center style="color :white;">GetParking. The Smart Parking System</h1></td>
			</tr>
			<tr><td bgcolor="#FA5858"><marquee behavior="alternate">Selamat Datang di GetParking. The Smart Parking System</marquee></td></tr>
			<tr>
				<td bgcolor=#FFF><br><p align=center><img src="images/logo.png"/><br><br>Selamat Datang di GetParking. The Smart Parking System <br>silahkan login jika Anda sudah memiliki akun <br><br><a href="login.php"><button>Login</button></a></p><br><br></td>
			</tr>
		</table>
	</center><br>
	</body background="images/background.jpg">
</html>
